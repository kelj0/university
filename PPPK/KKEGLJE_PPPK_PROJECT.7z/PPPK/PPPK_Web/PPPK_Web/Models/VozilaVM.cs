﻿using PPPK_Web.HELPERS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PPPK_Web.Models
{
    public class VozilaVM
    {
        public vozilo vozilo { get; set; }
        public tip_vozila tip_vozila { get; set; }
    }
}